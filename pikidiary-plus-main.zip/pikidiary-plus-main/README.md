# PikiDiary+ BETA
An unofficial extension for https://pikidiary.lol
# Features
- Post idea generator
# How to Install (from repo)
- Go to chrome://extensions

- Extract the extension zip to a safe location

- Click "Load unpacked"

![image](https://github.com/user-attachments/assets/21ce1512-68a2-4f82-9a9e-741147101c5b)

- Select the extracted folder

- Enjoy!
